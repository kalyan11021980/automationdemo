from __future__ import annotations

import logging
import logging.config
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# Must run before any settings/config imports

import uvicorn  # noqa: E402
import yaml  # noqa: E402

from a2a.server.apps import A2AStarletteApplication  # noqa: E402
from a2a.server.tasks import InMemoryTaskStore  # noqa: E402

from google.adk.a2a.executor.a2a_agent_executor import A2aAgentExecutor  # noqa: E402
from google.adk.a2a.utils.agent_card_builder import AgentCardBuilder  # noqa: E402
from google.adk.artifacts.in_memory_artifact_service import InMemoryArtifactService  # noqa: E402
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService  # noqa: E402
from google.adk.runners import Runner  # noqa: E402
from google.adk.sessions.in_memory_session_service import InMemorySessionService  # noqa: E402

from starlette.applications import Starlette  # noqa: E402
from starlette.middleware import Middleware  # noqa: E402
from starlette.middleware.cors import CORSMiddleware  # noqa: E402
from starlette.responses import JSONResponse  # noqa: E402
from starlette.routing import Route  # noqa: E402

from app.a2a.request_handler import NonBlockingRequestHandler  # noqa: E402
from app.agents.health_agent import health_agent  # noqa: E402
from app.observability import CorrelationIdFilter, RequestLoggingMiddleware  # noqa: E402
from app.tools.http_clients import close_all_clients  # noqa: E402

from config.settings import get_settings  # noqa: E402

A2A_PREFIX = "/dhs/api/v1/agent"

_session_service = InMemorySessionService()
_memory_service = InMemoryMemoryService()
_artifact_service = InMemoryArtifactService()

logger = logging.getLogger(__name__)


def setup_logging() -> None:
    """Set up logging from config/log-config.yaml with correlation ID."""
    config_path = Path(__file__).parent.parent / "config" / "log-config.yaml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            log_config = yaml.safe_load(f)
        logging.config.dictConfig(log_config)
    else:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )

    cid_filter = CorrelationIdFilter()
    for handler in logging.root.handlers:
        handler.addFilter(cid_filter)
    for lg in logging.Logger.manager.loggerDict.values():
        if isinstance(lg, logging.Logger):
            for handler in lg.handlers:
                handler.addFilter(cid_filter)

setup_logging()


def create_app() -> Starlette:
    """Build the A2A Starlette application."""
    settings = get_settings()

    logger.info(
        "Building ADK agent: model=%s api_base=%s",
        settings.litellm_model_string,
        settings.litellm_api_base,
    )

    async def create_runner() -> Runner:
        return Runner(
            app_name=health_agent.name,
            agent=health_agent,
            artifact_service=_artifact_service,
            session_service=_session_service,
            memory_service=_memory_service,
        )

    task_store = InMemoryTaskStore()
    agent_executor = A2aAgentExecutor(runner=create_runner)
    request_handler = NonBlockingRequestHandler(
        agent_executor=agent_executor,
        task_store=task_store,
    )

    async def health_check(request):
        return JSONResponse({"status": "ok", "service": "dhs-health-agent"})

    app = Starlette(
        routes=[Route("/health", health_check)],
        middleware=[
            Middleware(RequestLoggingMiddleware),
            Middleware(
                CORSMiddleware,
                allow_origins=["*"],
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            ),
        ],
    )

    async def setup_a2a():
        rpc_url = f"http://{settings.agent_host}:{settings.agent_port}{A2A_PREFIX}"
        card_builder = AgentCardBuilder(agent=health_agent, rpc_url=rpc_url)
        agent_card = await card_builder.build()
        a2a_app = A2AStarletteApplication(
            agent_card=agent_card,
            http_handler=request_handler,
        )
        a2a_app.add_routes_to_app(
            app,
            agent_card_url=f"{A2A_PREFIX}/.well-known/agent-card.json",
            rpc_url=f"{A2A_PREFIX}/",
        )
        logger.info("A2A agent mounted at %s", A2A_PREFIX)
        logger.info("Agent Card at %s/.well-known/agent-card.json", A2A_PREFIX)
        logger.info("JSON-RPC endpoint at %s/", A2A_PREFIX)

    app.add_event_handler("startup", setup_a2a)

    async def cleanup():
        """Clean up shared HTTP clients on shutdown."""
        await close_all_clients()
        logger.info("All HTTP clients closed")

    app.add_event_handler("shutdown", cleanup)
    return app


def main() -> None:
    """Start the A2A server."""
    settings = get_settings()
    app = create_app()
    logger.info(
        "Starting Health Records Agent on %s:%s",
        settings.agent_host,
        settings.agent_port,
    )
    uvicorn.run(
        app,
        host=settings.agent_host,
        port=settings.agent_port,
    )


if __name__ == "__main__":
    main()