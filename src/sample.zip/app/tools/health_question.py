"""Passthrough tool that routes health/medical questions to MedGemma.

Mistral calls this tool when it detects a health or medical question.
The before_model_callback intercepts the tool result and forwards
the question to MedGemma for a medical-domain response.
"""

from __future__ import annotations


async def answer_health_question(question: str) -> dict:
    """Answer a health or medical question.

    Call this tool when the user asks a health or medical question such as
    "What is diabetes?", "I have a fever", "What does cholesterol do?", or
    "Tell me about hypertension".

    Do NOT call this tool for:
    - Greetings or small talk
    - Requests to fetch medical records or visits
    - Follow-up questions about visit data already shown
    - Off-topic questions unrelated to health

    Args:
        question: The user's health or medical question, exactly as asked.

    Returns:
        A routing payload picked up by the callback pipeline.
    """
    return {"status": "routed", "question": question}
