"""Visit Details tool - retrieves comprehensive data for a single visit.

ADK FunctionTool: the framework reads the function signature, docstring,
and type hints to auto-generate the tool schema for the LLM.
"""
from __future__ import annotations

import logging
from typing import Any

import httpx

from app.tools.http_clients import get_visit_details_client
from app.tools.http_retry import handle_http_error, post_with_retry
from config.settings import get_settings

logger = logging.getLogger(__name__)


async def get_visit_details(
    profile_id: str,
    record_source_id: str,
    visit_id: str,
    location_id: str,
) -> dict[str, Any]:
    """Retrieve detailed information about a specific medical visit.

    Use this tool only when you have exact visit identifiers from the
    visit summaries. Returns diagnoses, medications, vitals, lab results,
    and provider notes for the specified visit.

    Args:
        profile_id: The retail profile ID of the patient.
        record_source_id: The record source ID from visit summaries (recordSourceId field).
        visit_id: The unique visit identifier from visit summaries (id field).
        location_id: The location ID from visit summaries (locationId field).

    Returns:
        A dictionary indicating the outcome.
        On success: {'status': 'success', 'type': 'VISIT_DETAILS_RAW',
            'visitId': '...', 'data': {...}}
        On error: {'status': 'error', 'error_message': '...'}
    """
    location_id = location_id or ""

    request_body = {
        "id": profile_id,
        "idType": "RETAIL_PROFILE_ID_TYPE",
        "recordSourceId": record_source_id,
        "resourceTypes": "VISIT_DETAILS",
        "operationContext": {
            "visitDetails": {
                "visitId": visit_id,
                "locationId": location_id,
            },
            "includeDetails": [],
        },
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    try:
        settings = get_settings()
        client = get_visit_details_client()
        response = await post_with_retry(client, settings.external_records_api_url, request_body, headers)
        data = response.json()

        if data.get("statusCode") not in ("0000", "0001"):
            return {
                "status": "error",
                "error_message": data.get("statusDescription", "Unknown error"),
            }

        resources: list[dict] = data.get("resources", [])
        if not resources:
            return {"status": "error", "error_message": "No visit details found"}

        return {
            "status": "success",
            "type": "VISIT_DETAILS_RAW",
            "visitId": visit_id,
            "data": resources[0],
        }

    except httpx.HTTPStatusError as exc:
        error_detail = handle_http_error(exc, request_body, logger)
        return {"status": "error", "error_message": f"HTTP Error {exc.response.status_code}: {error_detail}"}

    except httpx.TimeoutException as exc:
        logger.error("Timeout fetching visit details: %s", exc)
        return {"status": "error", "error_message": "The health records service is taking too long to respond. Please try again."}

    except httpx.RequestError as exc:
        logger.error("Connection error: %s", exc)
        return {"status": "error", "error_message": f"Connection error: {exc}"}

    except Exception as exc:
        logger.exception("Unexpected error in get_visit_details")
        return {"status": "error", "error_message": str(exc)}
