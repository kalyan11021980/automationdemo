"""Shared HTTP retry logic for external API calls."""
from __future__ import annotations

import json
import logging

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class RetryableHTTPError(Exception):
    """Raised for HTTP errors that should be retried."""


@retry(
    retry=retry_if_exception_type((RetryableHTTPError, httpx.ConnectError, httpx.ConnectTimeout)),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=8),
    reraise=True,
)
async def post_with_retry(
    client: httpx.AsyncClient, url: str, body: dict, headers: dict,
) -> httpx.Response:
    """POST with retry on transient failures."""
    response = await client.post(url, json=body, headers=headers)
    if response.status_code in RETRYABLE_STATUS_CODES:
        raise RetryableHTTPError(f"HTTP {response.status_code}")
    response.raise_for_status()
    return response


def handle_http_error(
    exc: httpx.HTTPStatusError, request_body: dict, log: logging.Logger,
) -> str:
    """Extract error detail from an HTTPStatusError and log it.

    Returns the error detail string.
    """
    error_detail = "Unknown error"
    try:
        error_data = exc.response.json()
        error_detail = (
            error_data.get("statusDescription")
            or error_data.get("message")
            or str(error_data)
        )
        log.error(
            "HTTP Error %d: %s. Request body: %s",
            exc.response.status_code,
            error_detail,
            json.dumps(request_body),
        )
    except Exception:
        log.error(
            "HTTP Error %d. Response: %s. Request body: %s",
            exc.response.status_code,
            exc.response.text[:500],
            json.dumps(request_body),
        )
    return error_detail
