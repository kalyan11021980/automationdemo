"""Visit Summaries tool - retrieves a patient's visit list.

ADK FunctionTool: the framework reads the function signature, docstring,
and type hints to auto-generate the tool schema for the LLM.
"""
from __future__ import annotations

import logging
from typing import Any

import httpx

from app.tools.http_clients import get_visit_summaries_client
from app.tools.http_retry import handle_http_error, post_with_retry
from config.settings import get_settings

logger = logging.getLogger(__name__)


async def get_visit_summaries(profile_id: str) -> dict[str, Any]:
    """Retrieve a list of all medical visits for a patient.

    Use this tool when the user asks to list, show, find, or get their visits.
    Returns visit dates, types, reasons, provider names, organisations, and
    record identifiers for all connected healthcare providers.

    Args:
        profile_id: The retail profile ID of the patient (e.g. '25430414612').

    Returns:
        A dictionary indicating the outcome.
        On success: {'status': 'success', 'type': 'VISIT_SUMMARIES',
            'profileId': '...', 'totalVisits': 2, 'visits': [...]}
        On empty: {'status': 'success', 'totalVisits': 0, 'visits': [],
            'message': 'No visits found for profile ID ...'}
        On error: {'status': 'error', 'error_message': '...', 'visits': []}
    """
    request_body = {
        "id": profile_id,
        "idType": "RETAIL_PROFILE_ID_TYPE",
        "resourceTypes": "VISIT_SUMMARY",
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    try:
        settings = get_settings()
        client = get_visit_summaries_client()
        response = await post_with_retry(client, settings.external_records_api_url, request_body, headers)
        data = response.json()

        if data.get("statusCode") not in ("0000", "0001"):
            return {
                "status": "error",
                "error_message": data.get("statusDescription", "Unknown error"),
                "visits": [],
            }

        resources: list[dict] = data.get("resources", [])
        if not resources:
            return {
                "status": "success",
                "type": "VISIT_SUMMARIES",
                "profileId": profile_id,
                "patientName": "Unknown",
                "totalVisits": 0,
                "visits": [],
                "message": f"No visits found for profile ID {profile_id}",
            }

        visits: list[dict] = []
        for visit in resources:
            visits.append({
                "id": visit.get("id", ""),
                "visitDate": visit.get("visitDate", "N/A"),
                "visitType": visit.get("visitType", "N/A"),
                "visitReason": visit.get("visitReason", "N/A"),
                "status": visit.get("status", "N/A"),
                "providerName": visit.get("providerName", "N/A"),
                "organizationName": visit.get("organizationName", "N/A"),
                "patientName": visit.get("patientName", "N/A"),
                "recordSourceId": visit.get("recordSourceId", ""),
                "recordSourceName": visit.get(
                    "connectedRecordSource", {},
                ).get("recordSourceName", "N/A"),
                "systemIdentifier": visit.get(
                    "connectedRecordSource", {},
                ).get("systemIdentifier", "N/A"),
                "locationId": visit.get("locationId", ""),
            })

        return {
            "status": "success",
            "type": "VISIT_SUMMARIES",
            "profileId": profile_id,
            "patientName": visits[0]["patientName"] if visits else "Unknown",
            "totalVisits": len(visits),
            "visits": visits,
        }

    except httpx.HTTPStatusError as exc:
        error_detail = handle_http_error(exc, request_body, logger)
        return {"status": "error", "error_message": f"HTTP Error {exc.response.status_code}: {error_detail}", "visits": []}

    except httpx.TimeoutException as exc:
        logger.error("Timeout fetching visit summaries: %s", exc)
        return {"status": "error", "error_message": "The health records service is taking too long to respond. Please try again.", "visits": []}

    except httpx.RequestError as exc:
        logger.error("Connection error: %s", exc)
        return {"status": "error", "error_message": f"Connection error: {exc}", "visits": []}

    except Exception as exc:
        logger.exception("Unexpected error in get_visit_summaries")
        return {"status": "error", "error_message": str(exc), "visits": []}
