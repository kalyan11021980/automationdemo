"""Shared HTTP client lifecycle management.

Provides connection-pooled ``httpx.AsyncClient`` instances for external API
calls and a ``close_all_clients`` helper for clean shutdown.
"""
from __future__ import annotations

import logging
from typing import Optional

import httpx

from config.settings import get_settings

logger = logging.getLogger(__name__)

_visit_summaries_client: Optional[httpx.AsyncClient] = None
_visit_details_client: Optional[httpx.AsyncClient] = None


def get_visit_summaries_client() -> httpx.AsyncClient:
    """Get or create the HTTP client for visit summaries."""
    global _visit_summaries_client
    if _visit_summaries_client is None:
        settings = get_settings()
        _visit_summaries_client = httpx.AsyncClient(
            timeout=30.0,
            verify=settings.ssl_verify,
            limits=httpx.Limits(
                max_keepalive_connections=10,
                max_connections=20,
                keepalive_expiry=30.0,
            ),
        )
    return _visit_summaries_client


def get_visit_details_client() -> httpx.AsyncClient:
    """Get or create the HTTP client for visit details."""
    global _visit_details_client
    if _visit_details_client is None:
        settings = get_settings()
        _visit_details_client = httpx.AsyncClient(
            timeout=60.0,
            verify=settings.ssl_verify,
            limits=httpx.Limits(
                max_keepalive_connections=10,
                max_connections=20,
                keepalive_expiry=30.0,
            ),
        )
    return _visit_details_client


async def close_all_clients() -> None:
    """Close all HTTP clients. Called during application shutdown."""
    global _visit_summaries_client, _visit_details_client

    for name, client in [
        ("visit_summaries", _visit_summaries_client),
        ("visit_details", _visit_details_client),
    ]:
        if client is not None:
            try:
                await client.aclose()
                logger.info("Closed %s HTTP client", name)
            except Exception:
                logger.exception("Failed to close %s HTTP client", name)

    _visit_summaries_client = None
    _visit_details_client = None
