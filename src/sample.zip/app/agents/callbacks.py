"""ADK agent lifecycle callbacks for Health101.

Handles: instruction injection, before/after model interception,
before/after tool hooks, and response wrapping for the generative UI.

MedGemma responder logic lives in ``app.agents.medgemma``.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.agents.readonly_context import ReadonlyContext
from google.adk.models import LlmRequest, LlmResponse
from google.adk.tools import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from app.agents.medgemma import call_medgemma, call_medgemma_health
from app.core.prompts import AGENT_SYSTEM_PROMPT
from app.core.response_wrapper import (
    ResponseType,
    unwrap_response_text,
    wrap_markdown,
    wrap_response,
)
from config.settings import get_settings

logger = logging.getLogger(__name__)

_STATE_KEY_VISIT_CONTEXT = "visit_context"
_STATE_KEY_PROFILE_ID = "profile_id"
_STATE_KEY_LAST_TOOL_NAME = "last_tool_name"
_STATE_KEY_LAST_TOOL_RESULT = "last_tool_result"
_STATE_KEY_TOOL_START_TIME = "tool_start_time"
_STATE_KEY_LLM_START_TIME = "llm_start_time"

_settings = get_settings()

# Guard-rails
_MAX_TOOL_RESULT_BYTES = 64_000  # ~64 KB cap on tool results stored in state
_MAX_VISIT_CONTEXT_CHARS = 8_000  # keep system prompt within safe bounds


def _log(msg: str, *args: object) -> None:
    """Print a timestamped log line (always visible, even under adk web)."""
    from datetime import datetime

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        body = msg % args if args else msg
    except (TypeError, ValueError):
        body = f"{msg} {args}"
    print(f"{ts} - TIMING - {body}", flush=True)


def _make_llm_response(text: str) -> LlmResponse:
    """Build an LlmResponse from plain text."""
    return LlmResponse(
        content=types.Content(
            role="model",
            parts=[types.Part(text=text)],
        ),
    )


# ---------------------------------------------------------------------------
# Agent callbacks
# ---------------------------------------------------------------------------

def root_instruction(context: ReadonlyContext) -> str:
    """Instruction provider: Health101 persona + dynamic state."""
    parts = [AGENT_SYSTEM_PROMPT]

    profile_id = context.state.get(_STATE_KEY_PROFILE_ID)
    if profile_id:
        parts.append(f"\nCurrent profile ID: {profile_id}")

    visit_context = context.state.get(_STATE_KEY_VISIT_CONTEXT)
    if visit_context:
        # Truncate to prevent oversized system prompts / context window abuse
        truncated = visit_context[:_MAX_VISIT_CONTEXT_CHARS]
        parts.append(
            "\nPreviously retrieved visit data (use these IDs when the "
            "user refers to a visit by number or description):\n"
            f"{truncated}"
        )

    return "\n".join(parts)


async def before_model_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest,
) -> Optional[LlmResponse]:
    """Intercept ONLY when a tool result is pending.

    After a tool executes, ADK loops back here before calling the model again.
    We intercept that loop, send the data to MedGemma for a medical explanation,
    wrap it for the UI, and return — skipping Mistral for this turn.

    For everything else (greetings, health questions, follow-ups, tool calls),
    return None and let Mistral handle it with full conversation history.
    """
    state = callback_context.state

    # --- Tool result pending → MedGemma explains the data ---
    last_tool_name = state.get(_STATE_KEY_LAST_TOOL_NAME)
    last_tool_result = state.get(_STATE_KEY_LAST_TOOL_RESULT)

    if last_tool_name and last_tool_result:
        # --- Health question → MedGemma answers directly ---
        if last_tool_name == "answer_health_question":
            try:
                tool_data = json.loads(last_tool_result)
                question = tool_data.get("question", "")
            except (json.JSONDecodeError, TypeError):
                question = ""

            if question:
                _log("intercepting orchestrator → routing health question to %s", _settings.llm_model)
                medgemma_text = await call_medgemma_health(question)
            else:
                medgemma_text = "I'm sorry, I couldn't understand the question. Could you please rephrase it?"

            wrapped = wrap_markdown(medgemma_text)
            state[_STATE_KEY_LAST_TOOL_NAME] = None
            state[_STATE_KEY_LAST_TOOL_RESULT] = None
            return _make_llm_response(wrapped)

        # --- Visit tool results → MedGemma explains the data ---
        # Extract user text for MedGemma context
        user_text = ""
        if llm_request.contents:
            for content in reversed(llm_request.contents):
                if content.role == "user" and content.parts:
                    for part in content.parts:
                        if hasattr(part, "text") and part.text:
                            user_text = part.text
                            break
                    if user_text:
                        break

        _log("intercepting orchestrator → routing tool=%s result to %s", last_tool_name, _settings.llm_model)
        medgemma_text = await call_medgemma(last_tool_name, last_tool_result, user_text)

        # Wrap with structured type for the UI
        try:
            tool_data = json.loads(last_tool_result)
        except (json.JSONDecodeError, TypeError):
            tool_data = None

        if tool_data and not (isinstance(tool_data, dict) and tool_data.get("status") == "error"):
            payload = {"data": tool_data, "summary": medgemma_text}
            if last_tool_name == "get_visit_summaries":
                wrapped = wrap_response(ResponseType.LIST_VISITS, payload)
            elif last_tool_name == "get_visit_details":
                wrapped = wrap_response(ResponseType.VISIT_SUMMARY, payload)
            else:
                wrapped = wrap_markdown(medgemma_text)
        else:
            wrapped = wrap_markdown(medgemma_text)

        # Clear tool state
        state[_STATE_KEY_LAST_TOOL_NAME] = None
        state[_STATE_KEY_LAST_TOOL_RESULT] = None

        return _make_llm_response(wrapped)

    # --- Receive profile_id from capability as A2A metadata or dev fallback for local testing only ---
    if not state.get(_STATE_KEY_PROFILE_ID):
        pid = None
        # 1. From A2A metadata (upstream service sets this after auth)
        if callback_context.run_config and callback_context.run_config.custom_metadata:
            a2a_meta = callback_context.run_config.custom_metadata.get("a2a_metadata", {})
            if isinstance(a2a_meta, dict):
                pid = a2a_meta.get("profile_id")
        # 2. Fallback: DEV_PROFILE_ID env var (local dev / ADK Web)
        if not pid and _settings.dev_profile_id:
            pid = _settings.dev_profile_id
        if pid:
            state[_STATE_KEY_PROFILE_ID] = str(pid)

    # --- Clean conversation history: unwrap JSON from previous model responses ---
    if llm_request.contents:
        for content in llm_request.contents:
            if content.role == "model" and content.parts:
                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        cleaned = unwrap_response_text(part.text)
                        if cleaned != part.text:
                            part.text = cleaned

    # Let orchestrator handle — record start time for after_model timing
    state[_STATE_KEY_LLM_START_TIME] = time.perf_counter()
    _log("orchestrator LLM call to %s starting", _settings.orchestrator_model)
    return None


def after_model_callback(
    callback_context: CallbackContext,
    llm_response: LlmResponse,
) -> Optional[LlmResponse]:
    """Wrap Mistral's text responses as MARKDOWN for the generative UI.

    Skip wrapping if the response contains a function_call (tool execution).
    """
    # Log orchestrator LLM duration
    start = callback_context.state.get(_STATE_KEY_LLM_START_TIME)
    if start:
        elapsed = time.perf_counter() - start
        _log("orchestrator LLM call to %s completed in %.2fs", _settings.orchestrator_model, elapsed)
        callback_context.state[_STATE_KEY_LLM_START_TIME] = None

    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return None

    # Don't wrap tool calls
    for part in llm_response.content.parts:
        if hasattr(part, "function_call") and part.function_call:
            return None

    # Extract text
    text = ""
    for part in llm_response.content.parts:
        if hasattr(part, "text") and part.text:
            text += part.text

    if not text:
        return None

    wrapped = wrap_markdown(text)
    return _make_llm_response(wrapped)


def root_before_tool_callback(
    tool: BaseTool,
    args: dict[str, Any],  # noqa: ARG001 — required by ADK callback signature
    tool_context: ToolContext,
) -> Optional[dict]:
    """Record tool start time for duration logging."""
    tool_context.state[_STATE_KEY_TOOL_START_TIME] = time.perf_counter()
    _log("tool call %s starting", tool.name)
    return None


def root_after_tool_callback(
    tool: BaseTool,
    args: dict[str, Any],  # noqa: ARG001 — required by ADK callback signature
    tool_context: ToolContext,
    tool_response: dict,
) -> Optional[dict]:
    """Store tool result in session state for before_model_callback to pick up."""
    try:  # noqa: BLE001 — intentional catch-all; callback must never crash the ADK loop
        tool_name = tool.name
        result_str = json.dumps(tool_response, default=str)

        # Log tool duration
        start = tool_context.state.get(_STATE_KEY_TOOL_START_TIME)
        if start:
            elapsed = time.perf_counter() - start
            _log("tool call %s completed in %.2fs (len=%d)", tool_name, elapsed, len(result_str))
            tool_context.state[_STATE_KEY_TOOL_START_TIME] = None
        else:
            _log("tool call %s completed (len=%d)", tool_name, len(result_str))

        # Cap tool result size to prevent state bloat from oversized API responses
        if len(result_str) > _MAX_TOOL_RESULT_BYTES:
            logger.warning(
                "tool %s result truncated from %d to %d bytes",
                tool_name, len(result_str), _MAX_TOOL_RESULT_BYTES,
            )
            result_str = result_str[:_MAX_TOOL_RESULT_BYTES]

        # Write both keys together so state is never partially set
        tool_context.state[_STATE_KEY_LAST_TOOL_NAME] = tool_name
        tool_context.state[_STATE_KEY_LAST_TOOL_RESULT] = result_str

        # Persist visit summaries for follow-up queries
        if tool_name == "get_visit_summaries":
            data = tool_response if isinstance(tool_response, dict) else json.loads(result_str)
            if data.get("visits") and data.get("status") != "error":
                tool_context.state[_STATE_KEY_VISIT_CONTEXT] = result_str

        # NOTE: profile_id is NOT taken from tool args — it must come from
        # trusted A2A metadata or the DEV_PROFILE_ID env var only.

    except (json.JSONDecodeError, TypeError, KeyError, AttributeError):
        logger.exception("root_after_tool_callback failed")
        # Clear both keys on failure to avoid stale/partial state
        tool_context.state[_STATE_KEY_LAST_TOOL_NAME] = None
        tool_context.state[_STATE_KEY_LAST_TOOL_RESULT] = None

    return None
