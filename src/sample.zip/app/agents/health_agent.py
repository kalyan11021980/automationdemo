from __future__ import annotations

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm

from app.agents.callbacks import (
    after_model_callback,
    before_model_callback,
    root_after_tool_callback,
    root_before_tool_callback,
    root_instruction,
)
from app.tools.health_question import answer_health_question
from app.tools.visit_details import get_visit_details
from app.tools.visit_summaries import get_visit_summaries
from config.settings import get_settings

settings = get_settings()

health_agent = LlmAgent(
    name="Health101",
    model=LiteLlm(
        model=settings.orchestrator_litellm_model,
        api_base=settings.orchestrator_litellm_api_base,
        api_key=settings.orchestrator_api_key,
        temperature=settings.orchestrator_temperature,
    ),
    instruction=root_instruction,
    description="Health assistant that answers health questions and fetches medical records.",
    tools=[get_visit_summaries, get_visit_details, answer_health_question],
    before_model_callback=before_model_callback,
    after_model_callback=after_model_callback,
    before_tool_callback=root_before_tool_callback,
    after_tool_callback=root_after_tool_callback,
)
