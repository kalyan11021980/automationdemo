from __future__ import annotations

import logging
import time
import uuid
from contextvars import ContextVar

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

correlation_id: ContextVar[str] = ContextVar("correlation_id", default="")


def new_correlation_id() -> str:
    """Generate and set a new correlation ID in the current context."""
    cid = uuid.uuid4().hex[:12]
    correlation_id.set(cid)
    return cid


class CorrelationIdFilter(logging.Filter):
    """Inject `correlation_id` into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.correlation_id = correlation_id.get("")  # type: ignore[attr-defined]
        return True


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log every HTTP request with method, path, status, and duration."""

    async def dispatch(self, request: Request, call_next) -> Response:
        cid = new_correlation_id()
        start = time.monotonic()
        logger = logging.getLogger("app.http")
        logger.info("[%s] → %s %s", cid, request.method, request.url.path)
        try:
            response = await call_next(request)
        except Exception:
            elapsed_ms = (time.monotonic() - start) * 1000
            logger.exception(
                "[%s] %s %s Failed after %.0fms",
                cid, request.method, request.url.path, elapsed_ms,
            )
            raise
        elapsed_ms = (time.monotonic() - start) * 1000
        logger.info(
            "[%s] ← %s %s %d (%.0fms)",
            cid, request.method, request.url.path, response.status_code, elapsed_ms,
        )
        response.headers["X-Correlation-ID"] = cid
        return response
