from __future__ import annotations

import asyncio
import logging
import uuid

from a2a.server.agent_execution import AgentExecutor, RequestContextBuilder
from a2a.server.context import ServerCallContext
from a2a.server.events import QueueManager
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import (
    PushNotificationConfigStore,
    PushNotificationSender,
    TaskStore,
)
from a2a.types import (
    Message,
    MessageSendParams,
    Part,
    Role,
    Task,
    TaskState,
    TaskStatus,
    TextPart,
)

logger = logging.getLogger(__name__)


class NonBlockingRequestHandler(DefaultRequestHandler):
    """Request handler with true non-blocking support.

    For blocking=False calls, the task is stored and returned
    immediately. Agent execution runs in the background and updates
    the same task in the store when finished.
    """

    def __init__(
        self,
        agent_executor: AgentExecutor,
        task_store: TaskStore,
        queue_manager: QueueManager | None = None,
        push_config_store: PushNotificationConfigStore | None = None,
        push_sender: PushNotificationSender | None = None,
        request_context_builder: RequestContextBuilder | None = None,
    ) -> None:
        super().__init__(
            agent_executor=agent_executor,
            task_store=task_store,
            queue_manager=queue_manager,
            push_config_store=push_config_store,
            push_sender=push_sender,
            request_context_builder=request_context_builder,
        )

    async def on_message_send(
        self,
        params: MessageSendParams,
        context: ServerCallContext | None = None,
    ) -> Message | Task:
        """Handle message/send with true non-blocking support.

        If params.configuration.blocking is False:
        - Create a placeholder task (state=submitted) in the task store
        - Start agent execution in a background asyncio.Task
        - Return the placeholder task immediately (<1s)

        Otherwise, delegates to the parent (blocking) implementation.
        """
        is_non_blocking = (
            params.configuration
            and params.configuration.blocking is False
        )

        if not is_non_blocking:
            return await super().on_message_send(params, context)

        logger.info("Non-blocking message/send: creating task immediately")
        task_id = params.message.task_id or str(uuid.uuid4())
        context_id = params.message.context_id or str(uuid.uuid4())

        params.message.task_id = task_id
        params.message.context_id = context_id

        history = [params.message] if params.message else []

        placeholder = Task(
            id=task_id,
            context_id=context_id,
            status=TaskStatus(
                state=TaskState.submitted,
                message=params.message,
            ),
            history=history,
        )

        await self.task_store.save(placeholder, context)

        logger.info(
            "Non-blocking task %s stored with state=submitted (context_id=%s)",
            task_id,
            context_id,
        )

        asyncio.create_task(
            self._run_blocking_in_background(params, context, task_id),
            name=f"nonblock:{task_id}",
        )

        return placeholder

    async def _run_blocking_in_background(
        self,
        params: MessageSendParams,
        context: ServerCallContext | None,
        task_id: str,
    ) -> None:
        """Run the full blocking agent pipeline in the background.

        The parent's ``on_message_send`` processes the agent and updates
        the task in the store. When it finishes, the task state moves
        from 'submitted' → 'completed' (or 'failed'), and subsequent
        tasks/get polls will see the final result.

        If the background execution fails, the task is updated to 'failed'
        with an error message so clients are not left polling indefinitely.
        """
        try:
            if params.configuration:
                params.configuration.blocking = True
            await super().on_message_send(params, context)
            logger.info("Background agent execution completed for task %s", task_id)
        except Exception:
            logger.exception("Background agent execution failed for task %s", task_id)
            try:
                error_message = Message(
                    message_id=str(uuid.uuid4()),
                    role=Role.agent,
                    parts=[Part(root=TextPart(
                        text="I encountered an error processing your request. Please try again.",
                    ))],
                )
                failed_task = Task(
                    id=task_id,
                    context_id=params.message.context_id or task_id,
                    status=TaskStatus(
                        state=TaskState.failed,
                        message=error_message,
                    ),
                )
                await self.task_store.save(failed_task, context)
                logger.info("Task %s marked as failed in store", task_id)
            except Exception:
                logger.exception("Failed to update task %s to failed state", task_id)
