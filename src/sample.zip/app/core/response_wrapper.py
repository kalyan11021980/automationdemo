from __future__ import annotations

import json
import logging
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ResponseType(str, Enum):
    """Response types for generative UI."""

    LIST_VISITS = "LIST_VISITS"
    VISIT_SUMMARY = "VISIT_SUMMARY"
    MARKDOWN = "MARKDOWN"


def wrap_response(response_type: ResponseType, response: Any) -> str:
    """Wrap response with response_type for generative UI.

    Args:
        response_type: The type of response (LIST_VISITS, VISIT_SUMMARY, MARKDOWN)
        response: The response data (dict for structured, str for markdown)

    Returns:
        JSON string with wrapped response
    """
    wrapped = {
        "response_type": response_type.value,
        "response": response,
    }
    return json.dumps(wrapped)


def wrap_markdown(text: str) -> str:
    """Wrap MARKDOWN response for free-form text.

    Args:
        text: Plain text or markdown content

    Returns:
        JSON string with response_type: MARKDOWN
    """
    logger.debug("Wrapping MARKDOWN response")
    return wrap_response(ResponseType.MARKDOWN, text)


def unwrap_response_text(content: str) -> str:
    """Extract the human-readable text from a wrapped response.

    Used to strip JSON wrappers from previous model responses when building
    conversation history, so the LLM sees clean text rather than JSON envelopes.

    Returns the original string if it's not a wrapped response.
    """
    try:
        data = json.loads(content)
        if isinstance(data, dict) and "response_type" in data and "response" in data:
            response = data["response"]
            if isinstance(response, str):
                return response
            return json.dumps(response)
        return content
    except (json.JSONDecodeError, TypeError):
        return content

