"""Centralized configuration loaded from environment variables and .env file."""
import logging
from functools import lru_cache

from pydantic_settings import BaseSettings

logger = logging.getLogger(__name__)


class Settings(BaseSettings):
    """Application settings.

    Values are loaded from environment variables. For local development,
    place overrides in a ``.env`` file.
    """

    # --- TrueFoundry / LLM (MedGemma - responder) ---
    tf_base_url: str = ""
    tf_api_key: str = ""
    llm_model: str = ""

    # --- Orchestrator (Mistral - router) ---
    orchestrator_model: str = ""
    orchestrator_base_url: str = ""
    orchestrator_api_key: str = ""
    orchestrator_temperature: float = 0.2

    # --- External Health Records API ---
    external_records_api_url: str = ""
    ssl_verify: bool = True

    # --- Agent Server ---
    agent_host: str = "0.0.0.0"
    agent_port: int = 9001

    # --- Dev / testing fallback ---
    dev_profile_id: str = ""

    # MedGemma (responder) LiteLLM properties

    @property
    def litellm_model_string(self) -> str:
        """LiteLLM model string for OpenAI-compatible TrueFoundry endpoint."""
        return f"openai/{self.llm_model}"

    @property
    def litellm_api_base(self) -> str:
        """LiteLLM api_base with /v1 suffix for OpenAI compatibility."""
        base = self.tf_base_url.rstrip("/")
        return f"{base}/v1" if not base.endswith("/v1") else base

    # Mistral (orchestrator/router) LiteLLM properties

    @property
    def orchestrator_litellm_model(self) -> str:
        """LiteLLM model string for orchestrator (Mistral)."""
        return f"openai/{self.orchestrator_model}"

    @property
    def orchestrator_litellm_api_base(self) -> str:
        """LiteLLM api_base for orchestrator with /v1 suffix."""
        base = self.orchestrator_base_url.rstrip("/")
        return f"{base}/v1" if not base.endswith("/v1") else base

    @property
    def truefoundry_headers(self) -> dict[str, str]:
        """TrueFoundry specific extra headers."""
        return {
            "X-TFY-METADATA": "{}",
            "X-TFY-LOGGING-CONFIG": '{"enabled": true}',
        }

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }


@lru_cache
def get_settings() -> Settings:
    """Return a cached singleton of application settings."""
    return Settings()
